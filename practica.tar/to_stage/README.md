# PRO2 Practica
## Note for the jutge.org version
If you got this code from jutge.org, you are most likely my teacher, I would hightly recommend visiting the [github repo](https://github.com/wamuM/practica-pro2) which has a more structured code (directories, better makefile, etc) that wasn't allowed in jutge.org. 

Note: The executable in the github repo's version is `./target/program`

## General description of the task 
Some homework from my degree, you can find the problem statement and other information they gave us on `./statement/`. 
The main idea is to test our ability to create well documented modular code as well as use standart data structures and custom classes. 
We also have to formally prove the validity of two functions.  
